/*
 * fuction.h
 *
 * created: 2024/7/4
 *  author: 
 */

#ifndef _FUCTION_H
#define _FUCTION_H

#ifdef __cplusplus
extern "C" {
#endif

//����ģ������ֵ
#define ac1 800      //1200
#define ac2 800
#define ac3 800
#define ac4 800
#define ac5 800
#define ac6 800

//����ģ��������
#define a1 adc_read(0)
#define a2 adc_read(1)
#define a3 adc_read(4)
#define a4 adc_read(5)
#define a5 adc_read(6)
#define a6 adc_read(7)

//�ɼ��ҶȰ巵������ֵ 0-1
#define A0 gpio_read(22)
#define A1 gpio_read(23)
#define A2 gpio_read(24)
#define A3 gpio_read(28)
#define A4 gpio_read(29)
#define A5 gpio_read(14)
#define A6 gpio_read(15)
#define A7 gpio_read(16)
#define A8 gpio_read(17)
#define A9 gpio_read(25)
#define A10 gpio_read(26)
#define A11 gpio_read(27)

void speed(unsigned int L,unsigned int R);
void Date_process(void);
void Hunting_pid(float kp,float v);
void hunting_pid(float kp,float v);



#ifdef __cplusplus
}
#endif

#endif // _FUCTION_H

