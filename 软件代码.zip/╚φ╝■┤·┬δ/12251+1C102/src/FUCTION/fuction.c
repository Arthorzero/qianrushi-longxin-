
 

#include "ls1c102.h"

#include "main.h"
#include "fuction.h"
 
extern int aNowlocal;
extern int Nowlocal;
extern int local;
extern int Error;
extern int LastError;
extern int SumError;

extern int speed_left1;
extern int speed_left2;
extern int speed_right1;
extern int speed_right2;

extern int8_t p1[4];

extern int8_t MotorEncoderPolarity ; 							  //������Կ��Ʊ���
extern int32_t EncodeTotal[4];													//�����ݴ����ۻ�ת������ֵ����ת��������ת�ݼ�
extern int8_t MotorType; 								//���õ������

void speed(unsigned int L,unsigned int R)
{
 speed_left1=L;
 speed_left2=L;

 speed_right1=R;
 speed_right2=R;

 p1[0]=speed_left1;
 p1[1]=speed_left2;
 p1[2]=speed_right1;
 p1[3]=speed_right2;


    I2C_Write_Len(MOTOR_TYPE_ADDR,&MotorType,4);					//�ڵ�����͵�ַ��д�������ͱ��
	delay_ms(5);
	I2C_Write_Len(MOTOR_ENCODER_POLARITY_ADDR,&MotorEncoderPolarity,1);		//���õ����������
	delay_ms(5);


		I2C_Write_Len(MOTOR_FIXED_SPEED_ADDR,p1,4);
		delay_ms(1800);

}

//ģ�����Ҷ�
void Date_process(void)
	{
		if(a3>ac3 && a4>ac4)            Nowlocal = 0; //3��4ѹ��
		else if(a3>ac3)                 Nowlocal = 1;
		else if(a4>ac4)                 Nowlocal = -1;
		else if(a2>ac2 && a3>ac3)       Nowlocal = 2;
		else if(a4>ac4 && a5>ac5)       Nowlocal = -2;
		else if(a2>ac2)                 Nowlocal = 3;
		else if(a5>ac5)                 Nowlocal = -3;
		else if(a1>ac1 && a2>ac2)       Nowlocal = 4;
		else if(a5>ac5 && a6>ac6)       Nowlocal = -4;
		else if(a1>ac1)                 Nowlocal = 5;
		else if(a6>ac6)                 Nowlocal = -5;
		else Nowlocal = 0;
	}


//�������Ҷ�
	void Digital_Date_process(void)
	{
		if(A6 && A5)              aNowlocal = 0; //5��6ѹ��
		else if(A5)                aNowlocal = 1;
		else if(A6)                aNowlocal = -1;
		else if(A5 && A4)         aNowlocal = 2;
		else if(A6 && A7)         aNowlocal = -2;
		else if(A4)                aNowlocal = 3;
		else if(A7)                aNowlocal = -3;
		else if(A4 && A3)       	aNowlocal = 4;
		else if(A7 && A8)       	aNowlocal = -4;
		else if(A3)                aNowlocal = 5;
		else if(A8)                aNowlocal = -5;
		else if(A3 && A2)       	aNowlocal = 6;
		else if(A8 && A9)       	aNowlocal = -6;
		else if(A2 && A1)       	aNowlocal = 7;
		else if(A9 && A10)    	aNowlocal = -7;
		else if(A1 && A0)         aNowlocal = 8;
		else if(A10 && A11)   	aNowlocal = -8;
		else if(A0)                aNowlocal = 9;
		else if(A11)               aNowlocal = -9;
		else aNowlocal = 0;
	}

/********************
 *   pid����
 *******************/
 //ģ�����Ҷ�
void hunting_pid(float kp,float v)
	{
		float out=0;
		float ki=0;
		float kd=0.7;
		Date_process();   //��õ�ǰֵ
		Error = local - Nowlocal;  //���ƫ��ֵ
		SumError = Error + SumError;  //������
		out = kp*Error + ki*SumError + kd*(Error-LastError);
		LastError = Error;  //����ƫ��ֵ
		if(out > 0.8 * v)
		out = 0.8*v;
		if(out < -0.8 * v)
		out = -0.8*v;
		speed(v + out,v - out);
	}

	//�������Ҷ�
void Hunting_pid(float kp,float v)
	{
		float out=0;
		float ki=0;
		float kd=0.7;
		Date_process();   //��õ�ǰֵ
		Error = local - aNowlocal;  //���ƫ��ֵ
		SumError = Error + SumError;  //������
		out = kp*Error + ki*SumError + kd*(Error-LastError);
		LastError = Error;  //����ƫ��ֵ
		if(out > 0.8 * v)
		out = 0.8*v;
		if(out < -0.8 * v)
		out = -0.8*v;
		speed(v + out,v - out);
	}
	
	
	


