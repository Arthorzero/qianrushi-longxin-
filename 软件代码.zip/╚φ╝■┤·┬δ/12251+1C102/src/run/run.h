/*
 * run.h
 *
 * created: 2024/7/4
 *  author: 
 */

#ifndef _RUN_H
#define _RUN_H

#ifdef __cplusplus
extern "C" {
#endif

void turn_left(void);
void turn_right(void);
void home_out(void);
void go_home(void);
void stop_get(void);
void load_off(void);
void right_back(void);
void left_back(void);
void run(void);




#ifdef __cplusplus
}
#endif

#endif // _RUN_H

