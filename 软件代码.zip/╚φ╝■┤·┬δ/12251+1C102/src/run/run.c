
#include "main.h"
//��ת
void turn_left(void)
{

    while(!A0&&!A1&&!A2&&!A3)
    {
        hunting_pid(4,30);
    }
    speed(30,30);
    delay_ms(100);
    while(!A0||!A1)
    {
        speed(-30,30);
    }
    while(!A2||!A3)
    {
        speed(-20,20);
    }
    while(!A3||!A4)
    {
        speed(-10,10);
    }

}
//��ת
void turn_right(void)
{

    while(!A11&&!A10&&!A9&&!A8)
    {
        hunting_pid(4,30);
    }
    speed(30,30);
    delay_ms(100);
    while(!A11||!A10)
    {
        speed(30,-30);
    }
    while(!A9||!A8)
    {
        speed(20,-20);
    }
    while(!A8||!A7)
    {
        speed(10,-10);
    }

}
//�Ӽҳ���
void home_out(void)
{
    speed(30,30);
    delay_ms(200);
}
//�ؼ�
void go_home(void)
{
    while(!A0||!A1||!A2||!A3||!A4||!A5||!A6||!A7||!A8||!A9||!A10||!A11)
   {
        hunting_pid(4,30);
   }
    speed(10,10);
    delay_ms(100);
    speed(0,0);
    
    
}

void stop_get(void)
{
    char string0[100] = "seeandget";
    
   while(!A0||!A1||!A2||!A3||!A4||!A5||!A6||!A7||!A8||!A9||!A10||!A11)
   {
        hunting_pid(4,30);
   }
    speed(10,10);
    delay_ms(100);
    console_putstr(string0, 1);
    speed(0,0);
    delay_ms(800);
}
void load_off(void)
{
    char string0[100] = "seeandget";
    
 while(!A0||!A1||!A2||!A3||!A4||!A5||!A6||!A7||!A8||!A9||!A10||!A11)
   {
        hunting_pid(4,30);
   }
    speed(10,10);
    delay_ms(100);
    console_putstr(string0, 1);
    speed(0,0);
    delay_ms(1000);
}

void right_back(void)
{
    speed(-30,-30);
    delay_ms(400);

    while(!A11||!A10)
    {
        speed(30,-30);
    }
    while(!A9||!A8)
    {
        speed(20,-20);
    }
    while(!A8||!A7)
    {
        speed(10,-10);
    }
    
}
//������ת
void left_back(void)
{
    speed(-30,-30);
    delay_ms(400);

     while(!A0||!A1)
    {
        speed(-30,30);
    }
    while(!A2||!A3)
    {
        speed(-20,20);
    }
    while(!A3||!A4)
    {
        speed(-10,10);
    }

}
//·���滮
void run(void)
{
    if(console_getch(0)==1)
    {
    home_out();
    turn_left();
    stop_get();
    right_back();
    turn_right();
    turn_left();
    stop_get();
    right_back();
    while(!A11||!A10)
    {
        speed(30,-30);
    }
    while(!A9||!A8)
    {
        speed(20,-20);
    }
    while(!A8||!A7)
    {
        speed(10,-10);
    }
    stop_get();
    left_back();
    turn_right();
    turn_left();
    stop_get();
    right_back();
    load_off();
    right_back();
    turn_left();
    go_home();
    }

}



