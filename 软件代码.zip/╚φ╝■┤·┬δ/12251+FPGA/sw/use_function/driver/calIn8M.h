/*
 * CalIn8M.h
 *
 *  Created on: 2023年9月5日
 *      Author: j
 */

#ifndef DRIVER_CALIN8M_H_
#define DRIVER_CALIN8M_H_

//内部8M时钟频率计算
//return: kHZ
int cal_in8m_touch();


#endif /* DRIVER_CALIN8M_H_ */
